import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import Slider from '@react-native-community/slider';
import { Formik } from 'formik';
import * as Yup from 'yup';
const MOCK_BALANCE = 1500;

const IBAN_REGEX = /^[A-Z]{2}[0-9A-Z]{13,32}$/;
const PHONE_REGEX = /^\+?[1-9]\d{1,14}$/;

const formatIban = val => {
  if (!val) return '';
  const cleaned = val.toUpperCase().replace(/[^A-Z0-9]/g, '');
  return cleaned.match(/.{1,4}/g)?.join(' ') ?? cleaned;
};

const getValidationSchema = recipientType =>
  Yup.object().shape({
    recipient: Yup.string()
      .required('Recipient is required')
      .test(
        'recipient-format',
        recipientType === 'iban' ? 'Invalid IBAN format' : 'Invalid phone number',
        val => {
          if (!val) return false;
          const cleaned = val.replace(/\s+/g, '').toUpperCase();
          return recipientType === 'iban' ? IBAN_REGEX.test(cleaned) : PHONE_REGEX.test(val.trim());
        }
      ),
    amount: Yup.number()
      .typeError('Amount must be a number')
      .positive('Amount must be greater than zero')
      .max(MOCK_BALANCE, `Insufficient balance (max ${MOCK_BALANCE}$)`)
      .required('Amount is required'),
  });

export default function SendMoneyForm({ onNext }) {
  const [recipientType, setRecipientType] = useState('iban');

  return (
    <KeyboardAvoidingView
      behavior={Platform.select({ ios: 'padding', android: undefined })}
      style={{ flex: 1 }}
    >
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <Text style={styles.title}>Send Money</Text>

        <View style={styles.toggleContainer} accessibilityRole="tablist">
          <TouchableOpacity
            style={[styles.toggleBtn, recipientType === 'iban' && styles.toggleBtnActive]}
            onPress={() => setRecipientType('iban')}
            accessibilityRole="tab"
            accessibilityState={{ selected: recipientType === 'iban' }}
            accessibilityLabel="Select IBAN input"
          >
            <Text style={[styles.toggleText, recipientType === 'iban' && styles.toggleTextActive]}>IBAN</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.toggleBtn, recipientType === 'phone' && styles.toggleBtnActive]}
            onPress={() => setRecipientType('phone')}
            accessibilityRole="tab"
            accessibilityState={{ selected: recipientType === 'phone' }}
            accessibilityLabel="Select Phone input"
          >
            <Text style={[styles.toggleText, recipientType === 'phone' && styles.toggleTextActive]}>Phone</Text>
          </TouchableOpacity>
        </View>

        <Formik
          initialValues={{ recipient: '', amount: 0 }}
          validationSchema={getValidationSchema(recipientType)}
          onSubmit={values => onNext({
            recipient: values.recipient.trim(),
            amount: Number(values.amount),
            recipientType,
          })}
          validateOnMount
        >
          {({ handleChange, handleBlur, handleSubmit, values, errors, touched, setFieldValue, isValid, dirty }) => (
            <View>
              <Text style={styles.label}>{recipientType === 'iban' ? 'Recipient IBAN' : 'Recipient Phone'}</Text>
              <TextInput
                style={[styles.input, touched.recipient && errors.recipient ? styles.inputError : null]}
                onChangeText={text => {
                  if (recipientType === 'iban') {
                    setFieldValue('recipient', formatIban(text));
                  } else {
                    setFieldValue('recipient', text);
                  }
                }}
                onBlur={handleBlur('recipient')}
                value={values.recipient}
                placeholder={recipientType === 'iban' ? 'DE89 3704 0044 0532 0130 00' : '+1234567890'}
                keyboardType={recipientType === 'phone' ? 'phone-pad' : 'default'}
                autoCapitalize={recipientType === 'iban' ? 'characters' : 'none'}
                autoCorrect={false}
                accessibilityLabel={recipientType === 'iban' ? 'IBAN input' : 'Phone input'}
              />
              {touched.recipient && errors.recipient && <Text style={styles.error}>{errors.recipient}</Text>}

              <Text style={styles.label}>Amount (${values.amount.toFixed(0)})</Text>
              <Slider
                style={{ width: '100%', height: 40 }}
                minimumValue={0}
                maximumValue={MOCK_BALANCE}
                step={1}
                value={values.amount}
                onValueChange={val => setFieldValue('amount', val)}
                minimumTrackTintColor="#2563eb"
                maximumTrackTintColor="#cbd5e1"
                accessibilityLabel="Amount slider"
              />
              <TextInput
                style={[styles.input, touched.amount && errors.amount ? styles.inputError : null]}
                onChangeText={handleChange('amount')}
                onBlur={handleBlur('amount')}
                value={String(values.amount)}
                placeholder="Enter amount"
                keyboardType="numeric"
                accessibilityLabel="Amount input"
              />
              {touched.amount && errors.amount && <Text style={styles.error}>{errors.amount}</Text>}

              <Text style={styles.balance}>Available balance: ${MOCK_BALANCE}</Text>

              <TouchableOpacity
                style={[styles.button, !(isValid && dirty) && styles.buttonDisabled]}
                onPress={handleSubmit}
                disabled={!(isValid && dirty)}
                accessibilityRole="button"
                accessibilityLabel="Next button"
                accessibilityHint="Go to confirmation screen"
              >
                <Text style={styles.buttonText}>Next</Text>
              </TouchableOpacity>
            </View>
          )}
        </Formik>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
const styles = StyleSheet.create({
  container: { padding: 20, flexGrow: 1, backgroundColor: '#f9fafb', justifyContent: 'center' },
  title: { fontSize: 28, fontWeight: '700', marginBottom: 24, textAlign: 'center', color: '#1e293b' },
  toggleContainer: { flexDirection: 'row', alignSelf: 'center', marginBottom: 20, backgroundColor: '#e2e8f0', borderRadius: 10 },
  toggleBtn: { paddingVertical: 12, paddingHorizontal: 48 },
  toggleBtnActive: { backgroundColor: '#2563eb', borderRadius: 10 },
  toggleText: { fontSize: 18, fontWeight: '700', color: '#475569' },
  toggleTextActive: { color: 'white' },
  label: { fontSize: 16, fontWeight: '600', marginBottom: 8, color: '#334155' },
  input: { borderWidth: 1, borderColor: '#94a3b8', borderRadius: 10, marginBottom: 14, fontSize: 18, paddingVertical: 14, paddingHorizontal: 14, backgroundColor: 'white' },
  inputError: { borderColor: '#ef4444' },
  error: { color: '#ef4444', marginBottom: 12, fontWeight: '600' },
  balance: { fontSize: 14, fontWeight: '600', marginBottom: 20, textAlign: 'right', color: '#64748b' },
  button: { backgroundColor: '#2563eb', borderRadius: 10, paddingVertical: 16 },
  buttonDisabled: { backgroundColor: '#93c5fd' },
  buttonText: { color: 'white', fontWeight: '700', fontSize: 20, textAlign: 'center' },
});