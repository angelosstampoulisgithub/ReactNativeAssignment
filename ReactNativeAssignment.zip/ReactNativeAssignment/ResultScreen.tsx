import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
export default function ResultScreen({ result, onRestart }) {
  if (!result) return null;

  return (
    <View style={styles.container} accessible accessibilityLiveRegion="polite">
      <Text
        style={[styles.message, result.success ? styles.success : styles.error]}
        accessibilityRole="alert"
      >
        {result.message}
      </Text>
      <TouchableOpacity
        style={styles.button}
        onPress={onRestart}
        accessibilityRole="button"
        accessibilityLabel="Send another transfer"
      >
        <Text style={styles.buttonText}>Send Another</Text>
      </TouchableOpacity>
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex:1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f9fafb', padding: 30 },
  message: { fontWeight: 'bold', fontSize: 24, marginBottom: 30, textAlign: 'center' },
  success: { color: '#10b981' },
  error: { color: '#ef4444' },
  button: { backgroundColor: '#2563eb', borderRadius: 12, paddingVertical: 16, paddingHorizontal: 52 },
  buttonText: { fontSize: 20, color: 'white', fontWeight: '700' },
});