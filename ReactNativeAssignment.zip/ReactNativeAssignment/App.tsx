import React, { useState } from 'react';
import { SafeAreaView } from 'react-native';
import LoginScreen from './LoginScreen';
import SendMoneyForm from './SendMoneyForm';
import ConfirmationScreen from './ConfirmationScreen';
import ResultScreen from './ResultScreen';
const mockSendMoneyAPI = ({ recipient, amount }) =>
  new Promise((resolve, reject) => {
    setTimeout(() => {
      if (Math.random() < 0.85) resolve({ success: true });
      else reject(new Error('Network error. Please try again later.'));
    }, 2000);
  });

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [sendData, setSendData] = useState(null); // { recipient, amount, recipientType }
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState(null); // {success:boolean, message:string}

  const onLoginSuccess = () => {
    setLoggedIn(true);
    setResult(null);
    setSendData(null);
  };

  const onNext = data => {
    setSendData(data);
    setResult(null);
  };

  const onCancel = () => setSendData(null);

  const onConfirmSend = async () => {
    setSending(true);
    setResult(null);
    try {
      await mockSendMoneyAPI(sendData);
      setResult({ success: true, message: '🎉 Money sent successfully!' });
      setSendData(null);
    } catch (err) {
      setResult({ success: false, message: err.message || 'Unknown error' });
    } finally {
      setSending(false);
    }
  };

  const onRestart = () => {
    setResult(null);
    setSendData(null);
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      {!loggedIn && <LoginScreen onLoginSuccess={onLoginSuccess} />}
      {loggedIn && !sendData && !result && <SendMoneyForm onNext={onNext} />}
      {loggedIn && sendData && !result && (
        <ConfirmationScreen data={sendData} onCancel={onCancel} onConfirm={onConfirmSend} loading={sending} />
      )}
      {loggedIn && result && <ResultScreen result={result} onRestart={onRestart} />}
    </SafeAreaView>
  );
}