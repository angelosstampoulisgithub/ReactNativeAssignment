import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import LoginScreen from './LoginScreen';

describe('LoginScreen', () => {
  const onLoginSuccessMock = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders inputs and button', () => {
    const { getByPlaceholderText, getByTestId } = render(
      <LoginScreen onLoginSuccess={onLoginSuccessMock} />
    );
    expect(getByPlaceholderText('Username')).toBeTruthy();
    expect(getByPlaceholderText('Password')).toBeTruthy();
    expect(getByTestId('loginButton')).toBeTruthy();
  });

  it('disables button when inputs are empty', () => {
    const { getByTestId } = render(<LoginScreen onLoginSuccess={onLoginSuccessMock} />);
    const button = getByTestId('loginButton');
    expect(button.props.accessibilityState.disabled).toBe(true);
  });

  it('shows validation errors when empty fields are touched', async () => {
    const { getByText, getByTestId } = render(<LoginScreen onLoginSuccess={onLoginSuccessMock} />);
    const button = getByTestId('loginButton');

    fireEvent.press(button);

    await waitFor(() => {
      expect(getByText('Username is required')).toBeTruthy();
      expect(getByText('Password is required')).toBeTruthy();
    });
  });

  it('calls onLoginSuccess with valid credentials', async () => {
    const { getByTestId } = render(<LoginScreen onLoginSuccess={onLoginSuccessMock} />);

    fireEvent.changeText(getByTestId('usernameInput'), 'user');
    fireEvent.changeText(getByTestId('passwordInput'), 'password');
    fireEvent.press(getByTestId('loginButton'));

    await waitFor(() => {
      expect(onLoginSuccessMock).toHaveBeenCalled();
    });
  });

  it('does not call onLoginSuccess with invalid credentials', async () => {
    const alertMock = jest.spyOn(global, 'alert').mockImplementation(() => { });
    const { getByTestId } = render(<LoginScreen onLoginSuccess={onLoginSuccessMock} />);

    fireEvent.changeText(getByTestId('usernameInput'), 'wronguser');
    fireEvent.changeText(getByTestId('passwordInput'), 'wrongpass');
    fireEvent.press(getByTestId('loginButton'));

    await waitFor(() => {
      expect(onLoginSuccessMock).not.toHaveBeenCalled();
    });

    alertMock.mockRestore();
  });
});