import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { Formik } from 'formik';
import * as Yup from 'yup';
const MOCK_USERNAME = 'user';
const MOCK_PASSWORD = 'password';

const LoginSchema = Yup.object().shape({
  username: Yup.string().required('Username is required'),
  password: Yup.string().required('Password is required'),
});

export default function LoginScreen({ onLoginSuccess }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login to Continue</Text>
      <Formik
        initialValues={{ username: '', password: '' }}
        validationSchema={LoginSchema}
        onSubmit={values => {
          if (
            values.username.trim().toLowerCase() === MOCK_USERNAME.toLowerCase() &&
            values.password === MOCK_PASSWORD
          ) {
            onLoginSuccess();
          } else {
            Alert.alert('Login Failed', 'Invalid username or password');
          }
        }}
      >
        {({ handleChange, handleBlur, handleSubmit, values, errors, touched, isValid, dirty }) => (
          <>
            <Text style={styles.label}>Username</Text>
            <TextInput
              style={[styles.input, touched.username && errors.username ? styles.inputError : null]}
              onChangeText={handleChange('username')}
              onBlur={handleBlur('username')}
              value={values.username}
              placeholder="Username"
              accessibilityLabel="Username input"
              autoCapitalize="none"
              autoCorrect={false}
            />
            {touched.username && errors.username && <Text style={styles.error}>{errors.username}</Text>}

            <Text style={styles.label}>Password</Text>
            <TextInput
              style={[styles.input, touched.password && errors.password ? styles.inputError : null]}
              onChangeText={handleChange('password')}
              onBlur={handleBlur('password')}
              value={values.password}
              placeholder="Password"
              secureTextEntry
              accessibilityLabel="Password input"
              autoCapitalize="none"
              autoCorrect={false}
            />
            {touched.password && errors.password && <Text style={styles.error}>{errors.password}</Text>}

            <TouchableOpacity
              style={[styles.button, !(isValid && dirty) && styles.buttonDisabled]}
              onPress={handleSubmit}
              disabled={!(isValid && dirty)}
            >
              <Text style={styles.buttonText}>Login</Text>
            </TouchableOpacity>
          </>
        )}
      </Formik>
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex:1, justifyContent:'center', padding: 20, backgroundColor:'#f0f4f8' },
  title: { fontSize: 26, fontWeight: '700', marginBottom: 24, alignSelf: 'center' },
  label: { fontSize: 16, fontWeight: '600', marginBottom: 6 },
  input: {
    borderWidth: 1,
    borderColor: '#94a3b8',
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 18,
    backgroundColor: '#fff',
    marginBottom: 12,
  },
  inputError: {
    borderColor: '#ef4444',
  },
  error: {
    color: '#ef4444',
    marginBottom: 12,
    fontWeight: '600',
  },
  button: {
    backgroundColor: '#2563eb',
    borderRadius: 10,
    paddingVertical: 16,
  },
  buttonDisabled: {
    backgroundColor: '#93c5fd',
  },
  buttonText: {
    textAlign: 'center',
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
  },
});