import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
export default function ConfirmationScreen({ data, onCancel, onConfirm, loading }) {
  if (!data) return null;

  const { recipient, recipientType, amount } = data;

  return (
    <View style={styles.container} accessible accessibilityLiveRegion="polite">
      <Text style={styles.title}>Confirm Transfer</Text>
      <View style={styles.row}>
        <Text style={styles.label}>Recipient Type:</Text>
        <Text style={styles.value}>{recipientType.toUpperCase()}</Text>
      </View>
      <View style={styles.row}>
        <Text style={styles.label}>Recipient:</Text>
        <Text style={styles.value}>{recipient}</Text>
      </View>
      <View style={styles.row}>
        <Text style={styles.label}>Amount:</Text>
        <Text style={styles.value}>${amount.toFixed(2)}</Text>
      </View>

      {loading && <ActivityIndicator size="large" color="#2563eb" style={{ marginVertical: 20 }} accessibilityLabel="Sending" />}

      <View style={styles.buttons}>
        <TouchableOpacity
          style={[styles.button, styles.cancel]}
          onPress={onCancel}
          disabled={loading}
          accessibilityRole="button"
          accessibilityLabel="Cancel transfer"
        >
          <Text style={styles.buttonText}>Cancel</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, styles.send]}
          onPress={onConfirm}
          disabled={loading}
          accessibilityRole="button"
          accessibilityLabel="Confirm send transfer"
        >
          <Text style={styles.buttonText}>Send</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex:1, padding: 20, justifyContent: 'center', backgroundColor: '#f9fafb' },
  title: { fontSize: 28, fontWeight: '700', marginBottom: 24, color: '#1e293b', textAlign: 'center' },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16 },
  label: { fontWeight: '700', fontSize: 18, color: '#475569' },
  value: { fontWeight: '600', fontSize: 18, color: '#1e293b', maxWidth: '60%', textAlign: 'right' },
  buttons: { flexDirection: 'row', justifyContent: 'space-around', marginTop: 40 },
  button: { paddingVertical: 16, paddingHorizontal: 50, borderRadius: 12, minWidth: 130 },
  cancel: { backgroundColor: '#ef4444' },
  send: { backgroundColor: '#10b981' },
  buttonText: { fontWeight: 'bold', fontSize: 18, color: 'white', textAlign: 'center' },
});
